/* DARK MODE */

const body = document.body;
const darkToggle = document.getElementById("darkToggle");

darkToggle.addEventListener("click", () => {
body.classList.toggle("dark");
});


/* MOBILE MENU */

const menuToggle = document.getElementById("menuToggle");
const menu = document.getElementById("menu");

menuToggle.addEventListener("click", () => {
menu.classList.toggle("active");
});


/* CHATBOT */

const chatBot = document.getElementById("chatBot");
const chatToggle = document.getElementById("chatToggle");
const chatClose = document.getElementById("chatClose");
const chatBody = document.getElementById("chatBody");
const chatInput = document.getElementById("chatInput");

const qaData = {

"hello":"Hello! How can I help you?",
"hi":"Hi! I am Aqsa Bot.",
"services":"We provide Facebook & Instagram Ads services.",
"contact":"You can contact us from contact page.",
"bye":"Goodbye!"

};

chatToggle.onclick = () => {
chatBot.style.transform = "translateY(0)";
};

chatClose.onclick = () => {
chatBot.style.transform = "translateY(500px)";
};

chatInput.addEventListener("keypress", function(e){

if(e.key === "Enter"){

let userText = chatInput.value.toLowerCase().trim();
chatInput.value="";

chatBody.innerHTML += `<p><b>You:</b> ${userText}</p>`;

let answer = qaData[userText] || "Sorry I don't understand.";

chatBody.innerHTML += `<p><b>Bot:</b> ${answer}</p>`;

chatBody.scrollTop = chatBody.scrollHeight;

}

});
/* RESULT SCROLL ANIMATION */

const cards = document.querySelectorAll(".result-card");

window.addEventListener("scroll", () => {

cards.forEach(card => {

const cardTop = card.getBoundingClientRect().top;

if(cardTop < window.innerHeight - 100){
card.classList.add("show");
}

});

});