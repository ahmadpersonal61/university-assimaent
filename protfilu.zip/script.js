/* ================== DARK MODE TOGGLE ================== */
const body = document.body;
const darkToggle = document.getElementById("darkToggle");
darkToggle.addEventListener("click", () => body.classList.toggle("dark"));

/* ================== MOBILE MENU ================== */
const menuToggle = document.getElementById("menuToggle");
const menu = document.querySelector(".menu");

menuToggle.addEventListener("click", () => menu.classList.toggle("active"));
window.addEventListener("resize", () => {
  if(window.innerWidth > 768) menu.classList.remove("active");
});

/* ================== SCROLL ANIMATIONS ================== */
const observer = new IntersectionObserver(entries => {
  entries.forEach(entry => {
    if(entry.isIntersecting){
      entry.target.style.opacity = 1;
      entry.target.style.transform = "translateY(0)";
    }
  });
},{threshold:0.1});

document.querySelectorAll(".animate-text, .animate-card").forEach(el => observer.observe(el));

/* ================== COUNTERS ================== */
const counters = document.querySelectorAll(".counter");
counters.forEach(counter => {
  counter.innerText = "0";
  const update = () => {
    const target = +counter.getAttribute("data-target");
    const count = +counter.innerText;
    const increment = target / 200;
    if(count < target){
      counter.innerText = Math.ceil(count + increment);
      setTimeout(update,10);
    }else{
      counter.innerText = target;
    }
  }
  update();
});

/* ================== PORTFOLIO SLIDER ================== */
const slides = document.querySelectorAll(".portfolio-slider .slide");
let currentSlide = 0;
setInterval(() => {
  slides.forEach((slide,i) => slide.style.transform = `translateX(${100*(i-currentSlide)}%)`);
  currentSlide = (currentSlide + 1) % slides.length;
},3000);

/* ================== CHATBOT ================== */
const chatBot = document.getElementById("chatBot");
const chatToggle = document.getElementById("chatToggle");
const chatClose = document.getElementById("chatClose");
const chatBody = document.getElementById("chatBody");
const chatInput = document.getElementById("chatInput");

const qaData = {
  "hello": "Hello! How can I help you with Meta Ads or Marketing today?",
  "hi": "Hi there! I am Aqsa Bot, your marketing assistant.",
  "who are you": "I am Aqsa Bot. I help answer digital marketing questions.",
  "what is meta ads": "Meta Ads are advertising campaigns on Facebook and Instagram to grow your business.",
  "how can i scale ads": "You can scale ads by optimizing targeting, budget, and creatives while testing campaigns.",
  "contact": "You can contact us via our Contact page or hire me button.",
  "services": "We provide Facebook & Instagram Ads, lead generation, and performance marketing.",
  "thank you": "You're welcome! Let me know if you have any more questions.",
  "bye": "Goodbye! Have a great day."
};

/* Open/close chat */
chatToggle.addEventListener("click", () => chatBot.style.transform="translateY(0)");
chatClose.addEventListener("click", () => chatBot.style.transform="translateY(500px)");

/* Handle input */
chatInput.addEventListener("keypress", function(e){
  if(e.key==="Enter"){
    const userText = chatInput.value.toLowerCase().trim();
    chatInput.value="";
    const pUser = document.createElement("p");
    pUser.innerHTML = `<b>You:</b> ${userText}`;
    chatBody.appendChild(pUser);
    const answer = qaData[userText] || "Sorry, I don't have an answer for that. Try asking something else!";
    const pBot = document.createElement("p");
    pBot.innerHTML = `<b>Bot:</b> ${answer}`;
    chatBody.appendChild(pBot);
    chatBody.scrollTop = chatBody.scrollHeight;
  }
});

/* ================== SOCIAL ICON LINKS ================== */
document.querySelectorAll('.orbit .social').forEach((icon, idx) => {
  const links = ["https://facebook.com","https://instagram.com","https://linkedin.com","https://twitter.com"];
  icon.addEventListener("click", ()=> window.open(links[idx], "_blank"));
});
